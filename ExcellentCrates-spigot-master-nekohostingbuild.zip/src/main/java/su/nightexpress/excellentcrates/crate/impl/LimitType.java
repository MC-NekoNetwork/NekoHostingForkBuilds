package su.nightexpress.excellentcrates.crate.impl;

public enum LimitType {
    GLOBAL, PLAYER
}
