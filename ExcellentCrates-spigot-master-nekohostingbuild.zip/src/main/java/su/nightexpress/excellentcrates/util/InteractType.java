package su.nightexpress.excellentcrates.util;

public enum InteractType {
    CRATE_OPEN,
    CRATE_MASS_OPEN,
    CRATE_PREVIEW
}
