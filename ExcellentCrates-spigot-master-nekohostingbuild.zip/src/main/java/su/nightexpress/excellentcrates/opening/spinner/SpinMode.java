package su.nightexpress.excellentcrates.opening.spinner;

public enum SpinMode {

    INDEPENDENT, SEQUENTAL, SYNCRHONIZED, RANDOM
}
