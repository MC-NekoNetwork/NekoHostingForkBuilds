<b>ExcellentCrates</b> is simple yet advanced Spigot crates plugin with a lot of unique and useful features with in-game
editor.
