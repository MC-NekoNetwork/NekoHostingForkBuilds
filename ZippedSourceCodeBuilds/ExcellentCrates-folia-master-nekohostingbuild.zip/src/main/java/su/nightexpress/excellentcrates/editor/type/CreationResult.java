package su.nightexpress.excellentcrates.editor.type;

public enum CreationResult {
    SUCCESS, ERROR_DUPLICATE, ERROR_NAME
}
