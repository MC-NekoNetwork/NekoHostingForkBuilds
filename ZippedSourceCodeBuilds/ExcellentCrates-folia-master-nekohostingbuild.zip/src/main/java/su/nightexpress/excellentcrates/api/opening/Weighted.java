package su.nightexpress.excellentcrates.api.opening;

public interface Weighted {

    //boolean checkRollChance();

    double getWeight();

    void setWeight(double weight);

    double getRollChance();
}
