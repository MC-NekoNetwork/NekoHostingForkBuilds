package su.nightexpress.nightcore.util;

//@BenchmarkMode({Mode.AverageTime})
//@OutputTimeUnit(TimeUnit.MILLISECONDS)
//@State(Scope.Benchmark)
//@Fork(value = 1, jvmArgs = {"-Xms2G", "-Xmx2G"})
public class BenchmarkLoop {

//    public static void main(String[] args) {
//    }

    /*public static void main(String[] args) throws RunnerException {
        Options opt = new OptionsBuilder()
            .include(BenchmarkLoop.class.getSimpleName())
            .forks(1)
            .build();

        new Runner(opt).run();
    }

    @Setup
    public void setup() {

    }

    @Benchmark
    public void first(Blackhole blackhole) {

    }

    @Benchmark
    public void second(Blackhole blackhole) {

    }*/

}
