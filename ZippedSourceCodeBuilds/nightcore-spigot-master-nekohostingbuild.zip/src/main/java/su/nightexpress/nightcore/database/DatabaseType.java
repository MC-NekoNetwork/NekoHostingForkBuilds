package su.nightexpress.nightcore.database;

public enum DatabaseType {

    MYSQL,
    SQLITE,
}
