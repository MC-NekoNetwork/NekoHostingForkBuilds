package su.nightexpress.nightcore.language.message;

public enum OutputType {
    CHAT, ACTION_BAR, TITLES, NONE,
}
