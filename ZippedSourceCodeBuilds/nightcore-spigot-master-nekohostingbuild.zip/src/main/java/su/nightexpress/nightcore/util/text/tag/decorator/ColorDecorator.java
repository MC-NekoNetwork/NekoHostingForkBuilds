package su.nightexpress.nightcore.util.text.tag.decorator;

public interface ColorDecorator extends Decorator {

    // Exists just to clarify color decorators.
}
