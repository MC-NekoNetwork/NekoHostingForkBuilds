package su.nightexpress.nightcore.util.text.tag.decorator;

import net.md_5.bungee.api.chat.BaseComponent;
import org.jetbrains.annotations.NotNull;

public interface Decorator {

    void decorate(@NotNull BaseComponent component);
}
