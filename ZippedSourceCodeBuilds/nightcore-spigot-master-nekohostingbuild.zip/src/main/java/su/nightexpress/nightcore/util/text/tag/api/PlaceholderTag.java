package su.nightexpress.nightcore.util.text.tag.api;

import org.jetbrains.annotations.NotNull;

public interface PlaceholderTag {

    @NotNull String getValue();
}
