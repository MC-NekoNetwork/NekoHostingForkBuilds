package su.nightexpress.excellentcrates.hooks;

public class HookId {

    public static final String DECENT_HOLOGRAMS = "DecentHolograms";
    public static final String PROTOCOL_LIB = "ProtocolLib";
    public static final String COINS_ENGINE = "CoinsEngine";
}
