package su.nightexpress.excellentcrates.hologram;

public enum HologramType {
    INTERNAL,
    DECENT_HOLOGRAMS,
}
